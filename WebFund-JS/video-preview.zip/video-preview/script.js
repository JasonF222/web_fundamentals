console.log("page loaded...");

function play(element) {
    var x = document.createElement("nothingahead.mp4");
    var x = document.getElementById("nothingahead.mp4")
vid.muted = true;
}


// function pause(element) {

// }