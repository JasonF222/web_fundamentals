// Challenge #1 //

for(var i = 0; i < 21; i++) {
    if(i % 2 !== 0) console.log(i);
}

// Challenge #2 //

for(var i = 100; i > 0; i--) {
    if(i % 3 === 0) console.log(i);
}

// Challenge #3 //
var array = [4, 2.5, 1, -0.5, -2, -3.5]
for(var i = 0; i <array.length; i++) {
    console.log (array[i]);
}

// Challenge #4 //

var sum = 0;
for(var i = 0; i < 101; i++) {
    sum = sum + i;
}
console.log(sum);

// Challenge #5 //

var product = 1;
for(var i = 1; i < 13; i++) {
    product = product * i;
}
console.log(product);